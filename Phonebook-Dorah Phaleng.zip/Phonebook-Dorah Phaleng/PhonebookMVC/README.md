# Phonebook : MVC

A simple phonebook ☎️ application including users, contacts, contact groups and phone numbers.

Using .NET framework 4.8.1, ASP.NET MVC, Entity Framework and MS SQL Server.

