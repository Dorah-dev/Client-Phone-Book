﻿namespace PhonebookMVC.Models
{
    public class BaseModel
    {
        public int ID { get; set; }
    }
}