﻿/// <reference path="jquery-3.6.4.js" />
/// <reference path="modernizr-2.8.3.js" />
/// <autosync enabled="true" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="bootstrap.js" />
/// <reference path="respond.js" />
