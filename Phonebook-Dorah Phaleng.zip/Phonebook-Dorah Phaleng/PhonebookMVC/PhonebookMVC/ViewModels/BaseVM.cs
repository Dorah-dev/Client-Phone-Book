﻿namespace PhonebookMVC.ViewModels
{
    public class BaseVM
    {
        public int ID { get; set; }
    }
}