﻿namespace PhonebookMVC.ViewModels.Contacts
{
    public enum ContactSorting
    {
        FirstNameAsc,
        FirstNameDesc,
        LastNameAsc,
        LastNameDesc,
        EmailAsc,
        EmailDesc
    }
}