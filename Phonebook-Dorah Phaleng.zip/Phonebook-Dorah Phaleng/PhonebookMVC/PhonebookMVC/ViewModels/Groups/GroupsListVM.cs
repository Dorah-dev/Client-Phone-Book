﻿using PhonebookMVC.Models;

namespace PhonebookMVC.ViewModels.Groups
{
    public class GroupsListVM : BaseListVM<Group>
    {
    }
}