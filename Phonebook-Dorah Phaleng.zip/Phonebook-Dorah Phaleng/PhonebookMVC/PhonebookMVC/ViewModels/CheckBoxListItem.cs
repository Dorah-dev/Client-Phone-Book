﻿namespace PhonebookMVC.ViewModels
{
    public class CheckBoxListItem : BaseVM
    {
        public string Text { get; set; }

        public bool IsChecked { get; set; }
    }
}