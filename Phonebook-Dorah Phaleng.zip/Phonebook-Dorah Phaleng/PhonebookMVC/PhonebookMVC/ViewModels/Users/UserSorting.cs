﻿namespace PhonebookMVC.ViewModels.Users
{
    public enum UserSorting
    {
        FirstNameAsc,
        FirstNameDesc,
        LastNameAsc,
        LastNameDesc,
        UsernameAsc,
        UsernameDesc,
        EmailAsc,
        EmailDesc
    }
}