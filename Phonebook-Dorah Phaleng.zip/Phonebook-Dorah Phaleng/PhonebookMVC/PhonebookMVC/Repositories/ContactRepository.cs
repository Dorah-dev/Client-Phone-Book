﻿using PhonebookMVC.Models;

namespace PhonebookMVC.Repositories
{
    public class ContactRepository : BaseRepository<Contact>
    {
    }
}