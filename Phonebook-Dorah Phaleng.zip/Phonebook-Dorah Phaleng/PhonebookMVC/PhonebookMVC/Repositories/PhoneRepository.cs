﻿using PhonebookMVC.Models;

namespace PhonebookMVC.Repositories
{
    public class PhoneRepository : BaseRepository<Phone>
    {
    }
}