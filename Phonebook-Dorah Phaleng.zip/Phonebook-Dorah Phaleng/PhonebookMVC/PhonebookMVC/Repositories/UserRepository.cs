﻿using PhonebookMVC.Models;

namespace PhonebookMVC.Repositories
{
    public class UserRepository : BaseRepository<User>
    {
    }
}