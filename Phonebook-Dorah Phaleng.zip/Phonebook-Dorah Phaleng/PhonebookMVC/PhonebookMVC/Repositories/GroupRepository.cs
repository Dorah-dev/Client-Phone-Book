﻿using PhonebookMVC.Models;

namespace PhonebookMVC.Repositories
{
    public class GroupRepository : BaseRepository<Group>
    {
    }
}